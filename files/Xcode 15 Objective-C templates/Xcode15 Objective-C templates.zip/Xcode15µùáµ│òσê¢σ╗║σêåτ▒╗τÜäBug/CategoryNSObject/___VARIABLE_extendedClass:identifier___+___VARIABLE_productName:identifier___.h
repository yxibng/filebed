//___FILEHEADER___

___IMPORTHEADER_extendedClass___

NS_ASSUME_NONNULL_BEGIN

@interface ___VARIABLE_extendedClass:identifier___ (___VARIABLE_productName:identifier___)

@end

NS_ASSUME_NONNULL_END
